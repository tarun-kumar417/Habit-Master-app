class ValidationTypes {
  static const String signinEmail = 'signin email';
  static const String signinPassword = 'signin password';
  static const String signupName = 'signin name';
  static const String signupFirstName = 'signup first name';
  static const String signupLastName = 'signup last name';
  static const String signupGender = 'signup gender';
  static const String signupPhoneNumber = 'signup phone number';
  static const String signupBirthDay = 'signup birthday day';
  static const String signupBirthMonth = 'signup birthday month';
  static const String signupBirthYear = 'signup birthday year';
}
